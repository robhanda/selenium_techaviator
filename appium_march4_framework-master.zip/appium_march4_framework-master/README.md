# appium_march4_framework


1)The framework is to test the scenerios of big basket app.
2)Can implement this for any application.
3)Have created seprate folder to store reports,screenshot,test data and test cases.
